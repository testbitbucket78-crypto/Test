import { TablesGuard } from './tables.guard';

export const guards = [TablesGuard];

export * from './tables.guard';
