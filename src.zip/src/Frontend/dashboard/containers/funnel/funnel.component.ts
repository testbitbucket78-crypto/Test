import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sb-funnel',
  templateUrl: './funnel.component.html',
  styleUrls: ['./funnel.component.scss']
})
export class FunnelComponent implements OnInit {
 

  constructor() { }

  ngOnInit(): void {
  }

}