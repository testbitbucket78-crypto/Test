import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sb-campaign-reports',
  templateUrl: './campaign-reports.component.html',
  styleUrls: ['./campaign-reports.component.scss']
})
export class CampaignReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
