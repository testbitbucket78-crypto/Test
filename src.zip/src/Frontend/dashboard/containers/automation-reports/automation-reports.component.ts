import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sb-automation-reports',
  templateUrl: './automation-reports.component.html',
  styleUrls: ['./automation-reports.component.scss']
})
export class AutomationReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
