import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sb-conversational-reports',
  templateUrl: './conversational-reports.component.html',
  styleUrls: ['./conversational-reports.component.scss']
})
export class ConversationalReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
