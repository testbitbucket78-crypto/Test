const request = require("request"),
  express = require("express"),
  body_parser = require("body-parser"),
  axios = require("axios").default,
  app = express().use(body_parser.json()); // creates express http server

require('dotenv').config()
const { json } = require("body-parser");
const db = require('../dbhelper');
const notify = require('./PushNotifications');
const aws = require('../awsHelper');
const Routing = require('../RoutingRules')
const token = process.env.WHATSAPP_TOKEN;
const incommingmsg = require('../IncommingMessages')
const mytoken = process.env.VERIFY_TOKEN;

app.listen(process.env.PORT, () => {
  console.log('Server is running on port ' + process.env.PORT);
});
app.get('/', (req, res) => {
  res.send("Welcome in Whatshap webhook ");
})
app.get("/webhook", (req, res) => {

  let mode = req.query["hub.mode"];
  let challange = req.query["hub.challenge"];
  let token = req.query["hub.verify_token"];

  if (mode && token) {
    if (mode === "subscribe" && token === mytoken) {
      res.status(200).send(challange);
    } else {
      res.status(403);
    }
  }

})



// Accepts POST requests at /webhook endpoint
app.post("/webhook", async (req, res) => {
  // Parse the request body from the POST

  try {
    console.log("===========================##############==========================")
    let body = req.body;

    // Check the Incoming webhook message    
    if (body != undefined) {
      console.log(JSON.stringify(body, null, 2))
    }
    else {
      res.status(404).send({
        msg: err,
        status: 404
      });
      return;
    }

    // info on WhatsApp text message payload: https://developers.facebook.com/docs/whatsapp/cloud-api/webhooks/payload-examples#text-messages

    let extractedMessage = await extractDataFromMessage(body)

    res.status(200).send({
      msg: "extractedMessage",
      status: 200
    });

  } catch (err) {
    db.errlog(err);
    res.status(500).send({
      msg: err,
      status: 500
    });
  }

});


async function extractDataFromMessage(body) {

  if (body.entry && body.entry.length > 0 && body.entry[0].changes && body.entry[0].changes.length > 0 &&
    body.entry[0].changes[0].value && body.entry[0].changes[0].value.messages && body.entry[0].changes[0].value.messages.length > 0
    && body.entry[0].changes[0].value.metadata) {

    let changes = body.entry[0].changes[0];

    let phone_number_id = changes.value.metadata.phone_number_id;
    let display_phone_number = changes.value.metadata.display_phone_number;
    let firstMessage = changes.value.messages[0];

    let from = firstMessage.from; // extract the phone number from the webhook payload

    let contact = changes.value.contacts && changes.value.contacts.length > 0 ? changes.value.contacts[0] : null;

    let contactName = contact.profile.name ? contact.profile.name : from;
    let phoneNo = contact.wa_id;
    let ExternalMessageId = body.entry[0].id;
    let message_text = firstMessage.text ? firstMessage.text.body : "";  // extract the message text from the webhook payload
    let message_media = firstMessage.type;

    let Message_template_id = firstMessage.id;
    let Type = firstMessage.type

    console.log(" body.entry " + phoneNo)
    let firstStatus = "";
    let Quick_reply_id = "";
    let uniqueId = "";

    if (changes.value.statuses && changes.value.statuses.length > 0) {
      firstStatus = changes.value.statuses[0];
      Quick_reply_id = firstStatus.id;
      uniqueId = firstStatus.recipient_id;
      console.log(Quick_reply_id + uniqueId);
      console.log("status present");
    }
    console.log("________________SAVEING MESSAGE___________________");
    // console.log(message_text)
    var saveMessages = await saveIncommingMessages(from, firstMessage, phone_number_id, display_phone_number, phoneNo, message_text, message_media, Message_template_id, Quick_reply_id, Type, ExternalMessageId, contactName)
    var SavedMessageDetails = await getDetatilsOfSavedMessage(saveMessages, message_text, phone_number_id, contactName, from, display_phone_number)
  }
  else if (body.entry && body.entry.length > 0 && body.entry[0].changes && body.entry[0].changes.length > 0 &&
    body.entry[0].changes[0].value && body.entry[0].changes[0].value.statuses &&
    body.entry[0].changes[0].value.statuses.length > 0 && body.entry[0].changes[0].value.statuses[0]) {

    let messageStatus = body.entry[0].changes[0].value.statuses[0].status

    console.log("messageStatus")
    console.log(messageStatus)
    let updatedStatus = await saveSendedMessageStatus(messageStatus)
  }

}




async function saveIncommingMessages(from, firstMessage, phone_number_id, display_phone_number, phoneNo, message_text, message_media, Message_template_id, Quick_reply_id, Type, ExternalMessageId, contactName) {
  if (Type == "image") {
    console.log("lets check the image");

    var imageurl = await saveImageFromReceivedMessage(from, firstMessage, phone_number_id, display_phone_number);

    message_media = imageurl.value;

    message_text = " "
    var media_type = 'image/jpg'
  }

  if (message_text.length > 0) {
    var saveMessage = await db.excuteQuery(process.env.query, [phoneNo, 'IN', message_text, message_media, Message_template_id, Quick_reply_id, Type, ExternalMessageId, display_phone_number, contactName, media_type]);

    console.log("====SAVED MESSAGE====" + " replyValue length  " + JSON.stringify(saveMessage));


  }
  return saveMessage;
}

async function getDetatilsOfSavedMessage(saveMessage, message_text, phone_number_id, contactName, from, display_phone_number) {
  if (saveMessage.length > 0) {
    console.log(display_phone_number + " .." + message_text)
    notify.NotifyServer(display_phone_number,'true');
    const data = saveMessage;
    // Extracting the values
    const extractedData = {
      sid: data[0][0]['@sid'],
      custid: data[2][0]['@custid'],
      agid: data[1][0]['@agid'],
      newId: data[3][0]['@newId'],
      replystatus: data[4][0]['@replystatus'],
      msg_id: data[5][0]['@msg_id'],
      newlyInteractionId: data[7][0]['@newlyInteractionId']
    };

    // console.log("getDetatilsOfSavedMessage");
    var sid = extractedData.sid
    var custid = extractedData.custid
    var agid = extractedData.agid
    var replystatus = extractedData.replystatus
    var newId = extractedData.newId
    var msg_id = extractedData.msg_id
    var newlyInteractionId = extractedData.newlyInteractionId



    let defaultQuery = 'select * from defaultActions where spid=?';
    let defaultAction = await db.excuteQuery(defaultQuery, [sid]);
    console.log(defaultAction.length)
    if (defaultAction.length > 0) {
      console.log(defaultAction[0].isAutoReply + " isAutoReply " + defaultAction[0].autoReplyTime + " autoReplyTime " + defaultAction[0].isAutoReplyDisable + " isAutoReplyDisable ")
      var isAutoReply = defaultAction[0].isAutoReply
      var autoReplyTime = defaultAction[0].autoReplyTime
      var isAutoReplyDisable = defaultAction[0].isAutoReplyDisable


    }
    let defaultReplyAction = await incommingmsg.autoReplyDefaultAction(isAutoReply, autoReplyTime, isAutoReplyDisable, message_text, phone_number_id, contactName, from, sid, custid, agid, replystatus, newId, msg_id, newlyInteractionId,'WhatsApp Official')
    let RoutingRulesVaues = await Routing.AssignToContactOwner(sid, newId, agid, custid)  // CALL Default Routing Rules
  }

}

async function saveImageFromReceivedMessage(from, message, phone_number_id, display_phone_number) {
  console.log("saveImageFromReceivedMessage")
  //https://graph.facebook.com/{{Version}}/{{Media-ID}}?phone_number_id=<PHONE_NUMBER_ID>
  return new Promise((resolve, reject) => {
    try {
      const response = axios({
        method: "GET", // Required, HTTP method, a string, e.g. POST, GET
        url:
          "https://graph.facebook.com/v17.0/" +
          message.image.id +
          "?phone_number_id=" + phone_number_id,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + token
        },

      }).then(async function (result) {
        console.log("the result is here")

        //TODO: NEED TO get SID from DB using Display phone number.
        //let sid = query to get using display phone number.
        let sid = await db.excuteQuery(process.env.findSpid, [display_phone_number])

        let awsDetails = await aws.uploadWhatsAppImageToAws(sid[0].SP_ID, message.image.id, result.data.url, token)//spid, imageid, fileUrl, fileAccessToken

        //TODO: Save the AWS url to DB in messages table using SP similar to webhook_2 SP. 

        notify.NotifyServer(display_phone_number,true);

        resolve({ value: awsDetails.value.Location });
      })
      //console.log("****image API****" + JSON.stringify(response))
    }
    catch (err) {
      console.log("______image api ERR_____" + err)
    }

  })
}

async function saveSendedMessageStatus(messageStatus) {

  let getMessageId = await db.excuteQuery(process.env.messageIdQuery, []);
  console.log(getMessageId)
  if (getMessageId.length > 0) {
    var message_id = getMessageId[0].Message_id;
  }
  console.log(message_id)
  let saveStatus = await db.excuteQuery(process.env.updateStatusQuery, [messageStatus, new Date(), message_id])
}