const apiUrl = 'https://staging.engageflo.com/api/set_webhook';
const webhookUrl = 'https://settings.sampanatechnologies.com/testwebhook';
const instanceId = '64D1F60FA644B';//64C8B2ED4B951
const accessToken = '64c4bcc7c05b1';
const baseURL='https://staging.engageflo.com/api/'

module.exports ={apiUrl,webhookUrl,instanceId,accessToken,baseURL}